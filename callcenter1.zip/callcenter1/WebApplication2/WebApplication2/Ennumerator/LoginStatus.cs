﻿public enum LoginStatus
{
    SuccesfullLogin,
    InvalIdAgentOrPin,
    AgentAlreadyLoggedIn,
    InvalidStationId,
    UnavailableStation,
    StationInUse
}

