﻿    public enum MessageType
    {
        Succes,
        Information, 
        Warning,
        Error,
        CriticalError
    }

