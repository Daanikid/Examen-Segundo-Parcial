﻿using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class StartCallController : ControllerBase
{
    [HttpPost("start")]
    public ActionResult StartCall(
        [FromHeader] int agent,
        [FromHeader] int pin,
        [FromHeader] string phone,
        [FromHeader] int station)
    {
        try
        {
            int callId = Session.StartCall(agent, pin, phone, station);
            return Ok(MessageResponse.GetReponse(0, $"Llamada iniciada. ID: {callId}", MessageType.Succes));
        }
        catch (Exception ex)
        {
            return Ok(MessageResponse.GetReponse(999, ex.Message, MessageType.CriticalError));
        }
    }
}