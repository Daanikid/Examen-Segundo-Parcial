﻿using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class EndCallController : ControllerBase
{
    [HttpPost("end")]
    public ActionResult EndCall(
        [FromHeader] int agent,
        [FromHeader] int callId,
        [FromHeader] int endStatus = 2) // 2 = Agent Ended por defecto
    {
        try
        {
            // Validar endStatus
            if (endStatus < 1 || endStatus > 4)
            {
                return BadRequest(MessageResponse.GetReponse(400, "Estado de finalización inválido", MessageType.Error));
            }

            bool success = Session.EndCall(callId, endStatus, agent);
            if (success)
            {
                return Ok(MessageResponse.GetReponse(0, "Llamada finalizada correctamente", MessageType.Succes));
            }
            else
            {
                return NotFound(MessageResponse.GetReponse(404, "Llamada no encontrada o no pertenece al agente", MessageType.Warning));
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, MessageResponse.GetReponse(500, ex.Message, MessageType.CriticalError));
        }
    }
}