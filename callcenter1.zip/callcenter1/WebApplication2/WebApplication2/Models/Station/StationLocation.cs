﻿
    public class StationLocation
    {
    public int Row { get; set; }
    public int Desk { get; set; }

    public StationLocation(int row, int desk)
    {
        Row = row;
        Desk = desk;
    }
}
