﻿using Microsoft.Data.SqlClient;
using System.Data;

public class Session
{
    #region properties

    // id int, dateTimeLogin datetime, dateTimeLogout datetime , IdAgent int, IdStation int, IdCurrentCall int , active int
    private int _id { get; set; }
    private DateTime _dateTimeLogin { get; set; }
    private DateTime _dateTimeLogout { get; set; }
    private int _idAgent { get; set; }
    private int _idStation { get; set; }
    private int _idCurrentCall { get; set; }
    private bool _active { get; set; }
    #endregion

    #region getterSetter

    public int id { get => _id; }
    public DateTime dateTimeLogin { get => _dateTimeLogin; set => _dateTimeLogin = value; }
    public DateTime dateTimeLogout { get => _dateTimeLogout; set => _dateTimeLogout = value; }
    public int idAgent { get => _idAgent; set => _idAgent = value; }
    public int idStation { get => _idStation; set => _idStation = value; }
    public int idCurrentCall { get => _idCurrentCall; set => _idCurrentCall = value; }
    public bool active { get => _active; set => _active = value; }

    #endregion

    #region statements

    private static string selectAll = @"select id, dateTimeLogin, dateTimeLogout, idAgent, idStation, idCurrentCall, active from sessions ";

    private static string selectOne = @"select id, dateTimeLogin, dateTimeLogout, idAgent, idStation, idCurrentCall, active from sessions where id = @ID";

    private static string selectSessionAgent = @"select id, dateTimeLogin, dateTimeLogout, idAgent, idStation, idCurrentCall, active from sessions where idAgent = @ID ";

    private static string selectSessionStation = @"select id, dateTimeLogin, dateTimeLogout, idAgent, idStation, idCurrentCall, active from sessions where idStation = @ID ";

    #endregion

    public Session(int id, DateTime dateTimeLogin, DateTime dateTimeLogout, int idAgent, int idStation, int idCurrentCall, bool active)
    {
        _id = id;
        _dateTimeLogin = dateTimeLogin;
        _dateTimeLogout = dateTimeLogout;
        _idAgent = idAgent;
        _idStation = idStation;
        _idCurrentCall = idCurrentCall;
        _active = active;
    }

    public static int Login(int agentId, int pin, int stationID)
    {
        //command
        SqlCommand command = new SqlCommand("spLoginAgent");
        //parameter
        command.Parameters.AddWithValue("@agentId", agentId);
        command.Parameters.AddWithValue("@agentPin", pin);
        command.Parameters.AddWithValue("@stationId", stationID);
        //execute procedure
        return SqlServerConnection.ExecuteProcedure(command);
    }

    public static List<Session> Get()
    {
        //command
        SqlCommand command = new SqlCommand(selectAll);
        //Populate
        return SessionMapper.ToList(SqlServerConnection.ExecuteQuery(command));
    }

    public static Session Get(int id)
    {
        SqlCommand command = new SqlCommand(selectOne);
        command.Parameters.AddWithValue("@ID", id);
        //Populate
        DataTable table = SqlServerConnection.ExecuteQuery(command);

        if (table.Rows.Count > 0)
        {
            return SessionMapper.ToObject(table.Rows[0]);
        }
        else
        {
            throw new AgentNotFoundException(id);
        }
    }

    public static Session GetSessionAgent(int id)
    {
        SqlCommand command = new SqlCommand(selectSessionAgent);
        command.Parameters.AddWithValue("@ID", id);
        //Populate
        DataTable table = SqlServerConnection.ExecuteQuery(command);

        if (table.Rows.Count > 0)
        {
            return SessionMapper.ToObject(table.Rows[0]);
        }
        else
        {
            throw new SessionNotFoundException(id);
        }
    }

    public static Session GetSessionStation(int id)
    {
        SqlCommand command = new SqlCommand(selectSessionStation);
        command.Parameters.AddWithValue("@ID", id);
        //Populate
        DataTable table = SqlServerConnection.ExecuteQuery(command);

        if (table.Rows.Count > 0)
        {
            return SessionMapper.ToObject(table.Rows[0]);
        }
        else
        {
            throw new SessionNotFoundException(id);
        }
    }

    public static int ReceiveCall(string phoneNumber)
    {
        using (SqlConnection conn = new SqlConnection("Server=MAL_EDUCADA;Database=callcenter2025;Trusted_Connection=True;TrustServerCertificate=True;"))
        {
            conn.Open();
            string query = @"
            INSERT INTO calls (phoneNumber, idStatus)
            OUTPUT INSERTED.id
            VALUES (@phoneNumber, 1); -- 1 = Queue
        ";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@phoneNumber", phoneNumber);
                return (int)cmd.ExecuteScalar();
            }
        }
    }

    public static bool AnswerCall(int callId, int sessionId)
    {
        using (SqlConnection conn = new SqlConnection("Server=MAL_EDUCADA;Database=callcenter2025;Trusted_Connection=True;TrustServerCertificate=True;"))
        {
            conn.Open();
            string query = @"
            UPDATE calls
            SET idSession = @sessionId,
                idStatus = 2, -- Answered
                datetimeAnswered = GETDATE()
            WHERE id = @callId AND idStatus = 1
        ";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@callId", callId);
                cmd.Parameters.AddWithValue("@sessionId", sessionId);
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }

    public static bool EndCall(int callId, int idStatusEnd)
    {
        using (SqlConnection conn = new SqlConnection("Server=MAL_EDUCADA;Database=callcenter2025;Trusted_Connection=True;TrustServerCertificate=True;"))
        {
            conn.Open();
            string query = @"
            UPDATE calls
            SET datetimeEnded = GETDATE(),
                idStatus = 3, -- Ended
                idStatusEnd = @endStatus
            WHERE id = @callId AND idStatus = 2
        ";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@callId", callId);
                cmd.Parameters.AddWithValue("@endStatus", idStatusEnd); // Ej: 2 = Agent Ended
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }

    public static int? GetNextCallInQueue()
    {
        using (SqlConnection conn = new SqlConnection("Server=MAL_EDUCADA;Database=callcenter2025;Trusted_Connection=True;TrustServerCertificate=True;"))
        {
            conn.Open();
            string query = @"
            SELECT TOP 1 id FROM calls
            WHERE idStatus = 1
            ORDER BY datetimeReceived ASC
        ";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                var result = cmd.ExecuteScalar();
                return result != null ? (int?)result : null;
            }
        }
    }

    // Método StartCall agregado
    public static int StartCall(int agentId, int pin, string phoneNumber, int stationId)
    {
        // 1. Verificar credenciales del agente y estación
        using (SqlConnection conn = new SqlConnection("Server=MAL_EDUCADA;Database=callcenter2025;Trusted_Connection=True;TrustServerCertificate=True;"))
        {
            conn.Open();

            // Verificar que el agente y pin coincidan
            string checkAgentQuery = "SELECT 1 FROM agents WHERE id = @agentId AND pin = @pin";
            using (SqlCommand cmd = new SqlCommand(checkAgentQuery, conn))
            {
                cmd.Parameters.AddWithValue("@agentId", agentId);
                cmd.Parameters.AddWithValue("@pin", pin);
                if (cmd.ExecuteScalar() == null)
                    throw new Exception("Credenciales de agente inválidas");
            }

            // Verificar que la estación esté activa
            string checkStationQuery = "SELECT 1 FROM stations WHERE id = @stationId AND active = 1";
            using (SqlCommand cmd = new SqlCommand(checkStationQuery, conn))
            {
                cmd.Parameters.AddWithValue("@stationId", stationId);
                if (cmd.ExecuteScalar() == null)
                    throw new Exception("Estación no activa o no existe");
            }

            // 2. Crear o obtener sesión activa
            int sessionId;
            string getSessionQuery = @"SELECT id FROM sessions 
                                 WHERE idAgent = @agentId AND idStation = @stationId AND active = 1";

            using (SqlCommand cmd = new SqlCommand(getSessionQuery, conn))
            {
                cmd.Parameters.AddWithValue("@agentId", agentId);
                cmd.Parameters.AddWithValue("@stationId", stationId);
                var result = cmd.ExecuteScalar();

                if (result == null)
                {
                    // Crear nueva sesión si no existe una activa
                    string createSessionQuery = @"INSERT INTO sessions (idAgent, idStation, dateTimeLogin, active)
                                           OUTPUT INSERTED.id
                                           VALUES (@agentId, @stationId, GETDATE(), 1)";

                    using (SqlCommand createCmd = new SqlCommand(createSessionQuery, conn))
                    {
                        createCmd.Parameters.AddWithValue("@agentId", agentId);
                        createCmd.Parameters.AddWithValue("@stationId", stationId);
                        sessionId = (int)createCmd.ExecuteScalar();
                    }
                }
                else
                {
                    sessionId = (int)result;
                }
            }

            // 3. Crear la llamada
            int callId = ReceiveCall(phoneNumber);

            // 4. Asignar llamada a la sesión
            string updateCallQuery = @"UPDATE calls 
                                 SET idSession = @sessionId, 
                                     idStatus = 2, -- Answered
                                     datetimeAnswered = GETDATE()
                                 WHERE id = @callId";

            using (SqlCommand cmd = new SqlCommand(updateCallQuery, conn))
            {
                cmd.Parameters.AddWithValue("@sessionId", sessionId);
                cmd.Parameters.AddWithValue("@callId", callId);
                cmd.ExecuteNonQuery();
            }

            // 5. Actualizar sesión con llamada actual
            string updateSessionQuery = @"UPDATE sessions 
                                   SET idCurrentCall = @callId 
                                   WHERE id = @sessionId";

            using (SqlCommand cmd = new SqlCommand(updateSessionQuery, conn))
            {
                cmd.Parameters.AddWithValue("@callId", callId);
                cmd.Parameters.AddWithValue("@sessionId", sessionId);
                cmd.ExecuteNonQuery();
            }

            return callId;
        }
    }

    // Método Logout agregado
    public static bool EndCall(int callId, int endStatus, int agentId)
    {
        using (SqlConnection conn = new SqlConnection("Server=MAL_EDUCADA;Database=callcenter2025;Trusted_Connection=True;TrustServerCertificate=True;"))
        {
            conn.Open();
            using (SqlTransaction transaction = conn.BeginTransaction())
            {
                try
                {
                    // 1. Verificar que la llamada existe y pertenece al agente
                    string verifyCallQuery = @"
                    SELECT 1 FROM calls c
                    JOIN sessions s ON c.idSession = s.id
                    WHERE c.id = @callId 
                    AND s.idAgent = @agentId
                    AND c.idStatus = 2"; // 2 = Answered

                    using (SqlCommand cmd = new SqlCommand(verifyCallQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@callId", callId);
                        cmd.Parameters.AddWithValue("@agentId", agentId);
                        if (cmd.ExecuteScalar() == null)
                        {
                            transaction.Rollback();
                            return false;
                        }
                    }

                    // 2. Terminar la llamada
                    string endCallQuery = @"
                    UPDATE calls 
                    SET datetimeEnded = GETDATE(),
                        idStatus = 3, -- Ended
                        idStatusEnd = @endStatus
                    WHERE id = @callId";

                    using (SqlCommand cmd = new SqlCommand(endCallQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@callId", callId);
                        cmd.Parameters.AddWithValue("@endStatus", endStatus);
                        cmd.ExecuteNonQuery();
                    }

                    // 3. Obtener idSession para actualizaciones posteriores
                    int sessionId;
                    string getSessionQuery = "SELECT idSession FROM calls WHERE id = @callId";
                    using (SqlCommand cmd = new SqlCommand(getSessionQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@callId", callId);
                        sessionId = (int)cmd.ExecuteScalar();
                    }

                    // 4. Actualizar la sesión (quitar llamada actual)
                    string updateSessionQuery = @"
                    UPDATE sessions 
                    SET idCurrentCall = NULL 
                    WHERE id = @sessionId";

                    using (SqlCommand cmd = new SqlCommand(updateSessionQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@sessionId", sessionId);
                        cmd.ExecuteNonQuery();
                    }

                    // 5. Cerrar el registro de log de sesión actual (On Call -> Available)
                    string updateLogQuery = @"
                    UPDATE sessionLog 
                    SET dateTimeEnd = GETDATE(),
                        idStatus = 1 -- Available
                    WHERE idSession = @sessionId 
                    AND dateTimeEnd IS NULL
                    AND idStatus = 2";
    
                using (SqlCommand cmd = new SqlCommand(updateLogQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@sessionId", sessionId);
                        cmd.ExecuteNonQuery();
                    }

                    // 6. Crear nuevo registro de log (Available)
                    string insertLogQuery = @"
                    INSERT INTO sessionLog (idSession, dateTimeStart, idStatus)
                    VALUES (@sessionId, GETDATE(), 1)"; 
    
                using (SqlCommand cmd = new SqlCommand(insertLogQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@sessionId", sessionId);
                        cmd.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return true;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw new Exception($"Error al finalizar llamada: {ex.Message}");
                }
            }
        }
    }
}