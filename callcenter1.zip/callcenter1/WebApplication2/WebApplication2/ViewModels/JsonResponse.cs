﻿    public abstract class JsonResponse
    {
        public int Status {  get; set; }
    }
