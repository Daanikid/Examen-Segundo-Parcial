﻿    public class Config
    {
        public ConfigSqlServer sqlServer { get; set; }
        public ConfigPaths Paths { get; set; }

        public static Config Configuration {get; set;} 
    }

