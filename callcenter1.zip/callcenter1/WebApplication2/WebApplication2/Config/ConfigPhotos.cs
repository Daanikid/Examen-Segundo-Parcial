﻿
    public class ConfigPhotos
    {
        public string Users { get; set; }
        public string Agents { get; set; }
    }
