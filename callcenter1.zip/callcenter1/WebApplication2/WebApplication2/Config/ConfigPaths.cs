﻿
    public class ConfigPaths
    {
        public string Domain {  get; set; }
        public ConfigPhotos Photos { get; set; }
    }
