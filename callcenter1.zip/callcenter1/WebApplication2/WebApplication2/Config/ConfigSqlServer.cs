﻿    public class ConfigSqlServer
    {
        public string Server { get; set; }
        public string Database { get; set; }
        public string TrustServer_Certificate { get; set; }   
        public string Trusted_Connection { get; set; }
        public string User { get; set; }
        public string Password { get; set; }


    }